import streamlit as st
import pandas as pd
import plotly.express as px

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans

# ==========================================
# PAGE CONFIGURATION
# ==========================================

st.set_page_config(
    page_title="Customer Segmentation",
    page_icon="👥",
    layout="wide"
)

st.title("👥 Customer Segmentation Dashboard")
st.write(
    "Analyze customer behavior and identify customer segments "
    "using K-Means clustering."
)

# ==========================================
# LOAD DATA
# ==========================================

@st.cache_data
def load_data():
    df = pd.read_csv("dataset/customer_data.csv")
    return df


df = load_data()

# ==========================================
# DATA PREVIEW
# ==========================================

with st.expander("📋 View Customer Data"):
    st.dataframe(
        df,
        use_container_width=True,
        hide_index=True
    )

# ==========================================
# FEATURES FOR CLUSTERING
# ==========================================

features = [
    "Total_Orders",
    "Total_Spend",
    "Avg_Order_Value",
    "Total_Quantity"
]

# Check required columns

missing_columns = [
    column for column in features
    if column not in df.columns
]

if missing_columns:

    st.error(
        "Missing columns: "
        + ", ".join(missing_columns)
    )

    st.stop()


# ==========================================
# SIDEBAR
# ==========================================

st.sidebar.header("⚙️ Segmentation Settings")

number_of_clusters = st.sidebar.slider(
    "Number of Customer Segments",
    min_value=2,
    max_value=8,
    value=4,
    step=1
)

# ==========================================
# STANDARDIZE FEATURES
# ==========================================

X = df[features].copy()

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)


# ==========================================
# K-MEANS CLUSTERING
# ==========================================

kmeans = KMeans(
    n_clusters=number_of_clusters,
    random_state=42,
    n_init=10
)

df["Segment"] = kmeans.fit_predict(X_scaled)


# ==========================================
# KPI SECTION
# ==========================================

total_customers = len(df)

total_spend = df["Total_Spend"].sum()

average_spend = df["Total_Spend"].mean()

average_orders = df["Total_Orders"].mean()


col1, col2, col3, col4 = st.columns(4)

col1.metric(
    "Total Customers",
    f"{total_customers:,}"
)

col2.metric(
    "Total Customer Spend",
    f"₹{total_spend:,.0f}"
)

col3.metric(
    "Average Customer Spend",
    f"₹{average_spend:,.0f}"
)

col4.metric(
    "Average Orders",
    f"{average_orders:.1f}"
)


st.divider()


# ==========================================
# CUSTOMER COUNT BY SEGMENT
# ==========================================

segment_counts = (
    df["Segment"]
    .value_counts()
    .sort_index()
    .reset_index()
)

segment_counts.columns = [
    "Segment",
    "Customers"
]

fig1 = px.bar(
    segment_counts,
    x="Segment",
    y="Customers",
    title="Number of Customers in Each Segment",
    text="Customers"
)

fig1.update_layout(
    xaxis_title="Customer Segment",
    yaxis_title="Number of Customers"
)

st.plotly_chart(
    fig1,
    use_container_width=True
)


# ==========================================
# SPENDING VS ORDERS
# ==========================================

fig2 = px.scatter(
    df,
    x="Total_Orders",
    y="Total_Spend",
    color="Segment",
    hover_data=[
        "Customer_ID",
        "Age",
        "Gender",
        "City",
        "Income"
    ],
    title="Customer Segments: Orders vs Spending"
)

fig2.update_layout(
    xaxis_title="Total Orders",
    yaxis_title="Total Spend (₹)"
)

st.plotly_chart(
    fig2,
    use_container_width=True
)


# ==========================================
# INCOME VS SPENDING
# ==========================================

fig3 = px.scatter(
    df,
    x="Income",
    y="Total_Spend",
    color="Segment",
    hover_data=[
        "Customer_ID",
        "Age",
        "Gender",
        "City"
    ],
    title="Income vs Customer Spending"
)

fig3.update_layout(
    xaxis_title="Annual Income",
    yaxis_title="Total Spend (₹)"
)

st.plotly_chart(
    fig3,
    use_container_width=True
)


# ==========================================
# SEGMENT SUMMARY
# ==========================================

st.subheader("📊 Customer Segment Characteristics")

segment_summary = (
    df.groupby("Segment")[features]
    .mean()
    .round(2)
)

st.dataframe(
    segment_summary,
    use_container_width=True
)


# ==========================================
# SEGMENT DETAILS
# ==========================================

st.subheader("🔍 Segment Details")

selected_segment = st.selectbox(
    "Select a customer segment",
    sorted(df["Segment"].unique())
)

selected_customers = df[
    df["Segment"] == selected_segment
]

st.write(
    f"Customers in Segment {selected_segment}: "
    f"{len(selected_customers)}"
)

st.dataframe(
    selected_customers,
    use_container_width=True,
    hide_index=True
)


# ==========================================
# DOWNLOAD RESULTS
# ==========================================

csv_data = df.to_csv(
    index=False
).encode("utf-8")

st.download_button(
    label="⬇️ Download Segmented Customer Data",
    data=csv_data,
    file_name="customer_segments.csv",
    mime="text/csv"
)


# ==========================================
# BUSINESS INSIGHTS
# ==========================================

st.subheader("💡 How to Interpret the Segments")

st.write(
    """
    **High-value customers:** High spending and frequent purchases.
    
    **Regular customers:** Moderate spending and purchase frequency.
    
    **Occasional customers:** Lower purchase frequency and spending.
    
    **Low-value customers:** Low spending and low purchase frequency.
    
    Note: The actual characteristics of each segment should be
    determined from the segment summary above rather than assuming
    a particular cluster number represents a specific customer type.
    """
)

st.success(
    "Customer segmentation completed successfully!"
)