import pandas as pd

from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

import matplotlib.pyplot as plt
import seaborn as sns


# ==========================================
# LOAD DATA
# ==========================================

df = pd.read_csv("dataset/customer_data.csv")

print("Dataset loaded successfully")
print(df.head())


# ==========================================
# CHECK DATA
# ==========================================

print("\nDataset Shape:")
print(df.shape)

print("\nMissing Values:")
print(df.isnull().sum())

print("\nData Types:")
print(df.dtypes)


# ==========================================
# SELECT FEATURES
# ==========================================

features = [
    "Total_Orders",
    "Total_Spend",
    "Avg_Order_Value",
    "Total_Quantity"
]

X = df[features]


# ==========================================
# STANDARDIZE DATA
# ==========================================

scaler = StandardScaler()

X_scaled = scaler.fit_transform(X)


# ==========================================
# FIND BEST NUMBER OF CLUSTERS
# ==========================================

inertia = []

K = range(2, 9)

for k in K:

    model = KMeans(
        n_clusters=k,
        random_state=42,
        n_init=10
    )

    model.fit(X_scaled)

    inertia.append(model.inertia__)


# ==========================================
# ELBOW METHOD
# ==========================================

plt.figure(figsize=(8, 5))

plt.plot(
    K,
    inertia,
    marker="o"
)

plt.title("Elbow Method")
plt.xlabel("Number of Clusters")
plt.ylabel("Inertia")

plt.tight_layout()

plt.show()


# ==========================================
# FINAL K-MEANS MODEL
# ==========================================

kmeans = KMeans(
    n_clusters=4,
    random_state=42,
    n_init=10
)

df["Segment"] = kmeans.fit_predict(X_scaled)


# ==========================================
# SILHOUETTE SCORE
# ==========================================

score = silhouette_score(
    X_scaled,
    df["Segment"]
)

print("\nSilhouette Score:")
print(round(score, 3))


# ==========================================
# SEGMENT SUMMARY
# ==========================================

summary = df.groupby("Segment")[features].mean()

print("\nCustomer Segment Summary:")
print(summary)


# ==========================================
# CUSTOMER COUNT BY SEGMENT
# ==========================================

print("\nCustomers per Segment:")

print(
    df["Segment"]
    .value_counts()
    .sort_index()
)


# ==========================================
# VISUALIZATION
# ==========================================

plt.figure(figsize=(10, 6))

sns.scatterplot(
    data=df,
    x="Total_Spend",
    y="Total_Orders",
    hue="Segment",
    palette="Set2",
    s=100
)

plt.title("Customer Segments")
plt.xlabel("Total Spend")
plt.ylabel("Total Orders")

plt.tight_layout()

plt.show()


# ==========================================
# SAVE RESULTS
# ==========================================

df.to_csv(
    "customer_segments.csv",
    index=False
)

print("\nSegmentation completed!")

print(
    "Results saved as customer_segments.csv"
)